package com.miciaha.rendezvous.persistence.observables;

import com.miciaha.rendezvous.entities.Contact;
import com.miciaha.rendezvous.entities.reports.ContactDetail;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.ArrayList;
import java.util.LinkedHashMap;

public class ContactDetailData {
    public static ObservableList<ContactDetail> contactDetails = FXCollections.observableArrayList();

    public static ObservableList<ContactDetail> getContactDetails(){
        setContactDetails();
        return contactDetails;
    }

    private static void setContactDetails() {
        LinkedHashMap<Integer, Integer> contactCount = new LinkedHashMap<>();

        ContactData.contactsList.forEach( x -> {
            contactCount.put(x.getId(),0);
        });

        AppointmentData.appointmentList.forEach( x -> {
            int contactId = x.getContact().getId();
            if(contactCount.containsKey(contactId)){
                contactCount.put(contactId, contactCount.get(contactId) + 1);
            }
        });

        ArrayList<Integer> contactIdKeys = new ArrayList<>(contactCount.keySet());
        ArrayList<Integer> counts = new ArrayList<>(contactCount.values());

        ArrayList<ContactDetail> tempContactList = new ArrayList<>();

        for (int contactId : contactIdKeys) {
            int count = counts.get(contactIdKeys.indexOf(contactId));
            Contact contact = ContactData.getContact(contactId);
            ContactDetail temp = new ContactDetail(contact, count);
            tempContactList.add(temp);
        }

        contactDetails = FXCollections.observableArrayList(tempContactList);
    }
}
