package com.miciaha.rendezvous.interfaces;

/**
 * The interface Db entity.
 */
public interface DBEntity {
    /**
     * Gets id.
     *
     * @return the id
     */
    int getId();
}
