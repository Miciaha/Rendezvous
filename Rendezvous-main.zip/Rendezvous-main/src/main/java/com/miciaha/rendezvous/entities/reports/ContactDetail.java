package com.miciaha.rendezvous.entities.reports;

import com.miciaha.rendezvous.entities.Contact;

public class ContactDetail {
    private Contact contact;
    private int count;

    public ContactDetail(Contact contact, int count){
        this.contact = contact;
        this.count = count;
    }

    public Contact getContact() {
        return contact;
    }

    public int getCount() {
        return count;
    }

    public void setContact(Contact contact) {
        this.contact = contact;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
