Title: Rendezvous (a.k.a. QAM2 Task 1: Java Application Development)
This application tracks customer appointments for our user, "Test."
I decided to name the application Rendezvous for a few reasons:
    1. This is an appointment scheduling application and "rendezvous" is synonymous with "appointment."
    2. The word rendezvous is of french origin which happens to be one of the language translation requirements.
    3. Naming an application, even for a class project, adds a layer of realism that pushes me to make my own work better.
    (I hope doing so is not against the rubric.)

The full scenario can be found here: https://github.com/Miciaha/Rendezvous

Created by: Miciaha Ivey (mivey37@wgu.edu)
Date: 4/29/2022
App Version: 1.0.0

IDE:    IntelliJ IDEA 2021.3.3 (Ultimate Edition)
JavaFX: 18 by JavaFX runtime of version 11.0.2
JDK:    openjdk-17 java version 17.0.2
MySQL:  mysql-connector-java-8.0.25

The additional report contains the date, time, username, and status of previous login attempts.

Running the program:
    - Download the directory to your computer.
    - Open your IDE of choice (preferably IntelliJ IDEA) open the project directory
    - Edit the Build and Run configurations :
        - Ensure that "Scheduling Application" is selected for the starting class
        - Select Java 17 as the SDK
    - This project requires the use of MySQL; ensure that it is up, running, and accepting connections.
    - The connection to the database from the application can be found in the project under utilities.database as SQLDBConnection.
    - Application Login Credentials: {Username="test", Password="test"}

If there are any issues, please reach out to me using the email above, or via GitHub.